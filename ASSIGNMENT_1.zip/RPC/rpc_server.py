from xmlrpc.server import SimpleXMLRPCServer

def add(a, b):
    return a + b

def subtract(a, b):
    return a - b

server = SimpleXMLRPCServer(("0.0.0.0", 8000), allow_none=True)
print("RPC Server running on EC2 at port 8000...")

server.register_function(add, "add")
server.register_function(subtract, "subtract")

server.serve_forever()
