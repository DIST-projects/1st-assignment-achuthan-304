import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class RMIClient {
    public static void main(String[] args) {
        try {
            String host = "18.207.94.13"; // replace this
            Registry registry = LocateRegistry.getRegistry(host, 1099);
            Calculator calc = (Calculator) registry.lookup("CalcService");

            System.out.println("Addition: " + calc.add(10, 5));
            System.out.println("Subtraction: " + calc.subtract(10, 5));

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
