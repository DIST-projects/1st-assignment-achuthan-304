print("===================================")
print(" Docker Container Execution Started ")
print("===================================")

print("Initializing Python environment...")
print("Checking runtime details...")

import sys
import platform
from datetime import datetime

print(f"Python version      : {sys.version}")
print(f"Platform            : {platform.system()} {platform.release()}")
print(f"Architecture        : {platform.machine()}")

print("Current date & time :", datetime.now())

print("All required modules loaded successfully.")
print("Main program logic executing...")

# Simulated work
for i in range(1, 6):
    print(f"Processing step {i}/5 completed")

print("Main program logic finished.")
print("Cleaning up resources...")

print("===================================")
print(" Docker Container Execution Ended ")
print("===================================")
